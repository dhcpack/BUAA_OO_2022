import re
import time
import subprocess


# java -jar uml-homework.jar list -s "open-close.mdj"

# def generare(program):
#     file = open("stdin.txt", "r")
#     stdin = file.read()
#
#     proc = subprocess.Popen("java -jar " + program, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
#                             stderr=subprocess.PIPE, shell=True)
#     start_time = time.time()
#     stdout, stderr = proc.communicate(stdin.encode())
#     end_time = time.time()
#     # print(end_time - start_time)
#     return str(stdout, encoding="utf-8").replace("\r", ""), end_time - start_time

def initial_testpoint():
    for i in range(8):
        file = open("testpoint" + str(i) + ".txt", "w")
        stdin = ""
        proc = subprocess.Popen("java -jar U4T1.jar dump -s test" + str(i) + ".mdj -n Model", stdin=subprocess.PIPE,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        stdout, stderr = proc.communicate(stdin.encode())
        file.write(str(stdout, encoding="utf-8").replace("\r", ""))
        file.close()
        # print(str(stdout, encoding="utf-8").replace("\r", ""))


def add_query():
    for i in range(11):
        file = open("testpoint" + str(i) + ".txt", "r")
        lines = list(file.read().strip("\n").split("\n"))
        file.close()
        file = open("point" + str(i) + ".txt", "w")
        uml_class = set()
        uml_method = set()
        for line in lines:
            if "UMLClass" in line:
                class_pattern = ".*?\"name\":\"(?P<class_name>.*?)\".*?$"
                pattern = re.compile(class_pattern)
                match = re.match(pattern, line)
                uml_class.add(match.group("class_name"))
            elif "UMLOperation" in line:
                operation_pattern = ".*?\"name\":\"(?P<method_name>.*?)\".*?$"
                pattern = re.compile(operation_pattern)
                match = re.match(pattern, line)
                uml_method.add(match.group("method_name"))
            file.write(line + "\n")
        # "CLASS_COUNT", "CLASS_SUBCLASS_COUNT classname", "CLASS_OPERATION_COUNT classname"
        # "CLASS_OPERATION_VISIBILITY classname methodname", "CLASS_OPERATION_COUPLING_DEGREE classname methodname"
        # "CLASS_ATTR_COUPLING_DEGREE classname", "CLASS_IMPLEMENT_INTERFACE_LIST classname"
        # "CLASS_DEPTH_OF_INHERITANCE classname"
        file.write("END_OF_MODEL\n")
        file.write("CLASS_COUNT\n")
        for c in uml_class:
            file.write("CLASS_SUBCLASS_COUNT " + c + "\n")
            file.write("CLASS_OPERATION_COUNT " + c + "\n")
            file.write("CLASS_ATTR_COUPLING_DEGREE " + c + "\n")
            file.write("CLASS_IMPLEMENT_INTERFACE_LIST " + c + "\n")
            file.write("CLASS_DEPTH_OF_INHERITANCE " + c + "\n")
        for c in uml_class:
            for m in uml_method:
                file.write("CLASS_OPERATION_VISIBILITY " + c + " " + m + "\n")
                file.write("CLASS_OPERATION_COUPLING_DEGREE " + c + " " + m + "\n")
        file.close()


def test(i, program):
    file = open("point" + str(i) + ".txt", "r")
    stdin = file.read()
    file.close()
    proc = subprocess.Popen("java -jar " + program, stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    stdout, stderr = proc.communicate(stdin.encode())
    if len(stderr) != 0:
        print("stderr:\n {}".format(str(stderr, encoding="utf-8").replace("\r", "")))
    return str(stdout, encoding="utf-8").replace("\r", "")


def write_stdout(filename, text):
    file = open(filename, "w")
    file.write(text)
    file.close()


if __name__ == "__main__":
    # initial_testpoint()
    # add_query()
    for i in range(1, 11):
        res_zyl = test(i, "hw13.jar")
        res_zqy = test(i, "hw13-zqy.jar")
        if res_zyl != res_zqy:
            print("testpoint{} Wrong Answer!".format(i))
            write_stdout("zyl_stdout testpoint {}.txt".format(i), res_zyl)
            write_stdout("zqy_stdout testpoint {}.txt".format(i), res_zqy)
        else:
            print("testpoint{} Accepted!".format(i))
