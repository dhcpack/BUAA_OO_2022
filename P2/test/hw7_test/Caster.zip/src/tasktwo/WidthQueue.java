package tasktwo;

import taskone.RequestQueue;

public class WidthQueue extends RequestQueue { }
