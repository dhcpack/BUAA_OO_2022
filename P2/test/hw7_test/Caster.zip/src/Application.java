import tasktwo.Task2;

public class Application {
    public static void main(String[] args) throws Exception {
        new Task2(args);
    }
}
