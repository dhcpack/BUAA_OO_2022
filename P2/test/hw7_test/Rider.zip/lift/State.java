package src.lift;

public interface State {
    public void behave();
}
