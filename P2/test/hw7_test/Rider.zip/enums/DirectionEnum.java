package src.enums;

public enum DirectionEnum {
    UP, DOWN
}
