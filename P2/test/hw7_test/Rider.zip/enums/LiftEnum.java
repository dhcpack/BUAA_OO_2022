package src.enums;

public enum LiftEnum {
    Vertical, Parallel
}
